# CS 110L Spring 2020 starter code

Assignment handouts are available [here](https://reberhardt.com/cs110l/spring-2020/).

Trying out these assignments? Adapting these for a class? [Please let us
know](mailto:ryan@reberhardt.com); we'd love to hear from you!

Please don't post solution code publicly on the internet. We have plagiarism
detection tools, but we'd rather make it hard to plagiarize in the first place.
